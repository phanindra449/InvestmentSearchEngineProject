﻿namespace Kanini.InvestmentSearchEngine.CompanyDetails.Exceptions
{
    public class DataNotFoundException:Exception
    {
        public DataNotFoundException()
        {
            
        }
        public DataNotFoundException(string message):base(message) { }
    }
}
